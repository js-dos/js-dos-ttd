SimpleAI v6 - 2011/06/23
------------------------

Contents
--------
1. Introduction
2. Usage
3. Parameters
4. Recommended configuration
5. Changelog
6. Dependencies
7. License
8. Support

1. Introduction
---------------
SimpleAI is an AI written for OpenTTD, which tries to imitate the old AI 
(the one which was present in TTD, and OpenTTD versions until 0.6.3) in
its playing style.
The AI builds simple point-to-point routes using road vehicles, trains
and aircraft. Station layout is similar to that of the old AI.
SimpleAI supports all default cargoes, but it will try to use most NewGRF
cargoes as well.

2. Usage
--------
This AI can be used just like any other AI, see http://wiki.openttd.org/AI_settings
for details.

3. Parameters
-------------
Number of days to start this AI after the previous one (give or take) - You can configure
how much time the AI will wait before founding its company.

Use trains - Allows/disallows building trains for SimpleAI.

Use road vehicles - Allows/disallows building road vehicles for SimpleAI.

Use aircraft - Allows/disallows building aircraft for SimpleAI.

Note: If you disallow using a specific vehicle type for all AIs in the Advanced settings,
these settings are overridden. However, if you want to change these settings during the
game, changing the AI's own settings is preferred, as it still allows to finish the route
under construction and to maintain existing vehicles.

Build new routes if transported percentage is smaller than this value - With this setting
you can configure how much SimpleAI will compete with other companies. The higher the value,
the more competitive SimpleAI will be. When building a new connection, firstly it checks
how much of the cargo is transported from the given industry by other companies. If it is
higher than this value, the AI will move on to another industry.

The chance of taking subsidies - This setting allows you to configure how much the AI will
go for subsidies. The AI will ignore subsudies if it is set to 0, and will always try to get
subsidies if it is set to 10. It is recommended to set it to a lower value if more instances
of SimpleAI are present in the game.

The maximum number of road vehicles on a route - You can configure how much road vehicles
are allowed to run on a single route. This is useful to avoid congestion.

Days to wait between building two routes - If a new route is built successfully, the AI will
wait for the configured time before it tries to build a new one. If this setting is set to 0,
the AI will try to build a new route immediately after the previous one.

Slowdown effect (how much the AI will become slower over time) - If this is enabled, the
waiting time defined in the previous setting will increase over time. With this the AI
will slow down if it has plenty of routes. You can configure how fast the waiting time
will increase.

Build company headquarters near towns - If on, the AI will build its HQ in a town.
Otherwise it will build its HQ near its first station. (old AI behaviour)

Signal type to be used - You can configure the type of signals used by the AI. Path signals
allow the closing of level crossings much before the train arrives, thus protecting road
vehicles from collision, but they may increase congestion on the roads.

Use NewGRF rail stations if available - If enabled, the AI will try to use NewGRF rail
stations for freight trains. Tested with the Industrial Stations Renewal 0.8.0.

4. Recommended configuration
----------------------------
It is advised to use the default vehicle set, although the AI may work with some NewGRF
vehicle sets as well (eGRVTS being one example). SimpleAI is not compatibile with articulated
road vehicles (it is no problem if there are articulated vehicles present, the AI just
won't use them), and most NewGRF train sets may cause problems because of the wide engine
choice and the shorter wagons, as the AI is only prepared for wagons that are half a tile long.

It is also recommended to enable building on slopes, as the AI doesn't terraform while
building tracks.

Disabling 90 degree turns for trains may cause problems, as trains may take 90 degree
turns to enter the depot at double rail stations.

This AI is suitable for running multiple instances of it, although it is better to lower
the subsidy chance factor if you're using multiple instances, so that not all instances
will try to build at the same place when a new subsidy appears.

5. Changelog
------------
v6
- Added comments to the code
- Written this readme
- Refitting train wagons
- Fix a bug when some old vehicles didn't get replaced at all
- Support for NewGRF train stations
- An option to use path signals at single rail stations
- Avoid going bankrupt because of station maintenance costs

v5
- Plane support
- Upgrading existing bridges
- An option to use PBS signals instead
- Bugfixes

v4
- Bugfixes again

v3
- Bugfix

v2
- Bugfixes
- Updated to NoAI API version 1.0
- Changeable settings in-game
- An option to use two-way signals (like in TTO)

v1
- First Bananas release
- A little change in pathfinder penalties

beta3
- Bugfixes
- Checking vehicles which are sitting in the depot

beta2
- Improvements in save/load
- Adding wagons to existing trains
- An option to make the AI slower as the time progresses
- Bugfixes

beta1
- Basic save/load support
- Adding road vehicles to an existing route, up to a limit chosen by the user
- Replacing older models with newer ones
- Added setting to specify the number of days to wait between building two routes
- Flipping passing lane sections
- A bit more consistency with the HQ builiding behaviour of the old AI, added a setting to build the HQ in a town

alpha5
- Double railway lines (in the style of the old AI)
- One more wagon is added to a train if the engine has only one unit
- Combined passenger/mail trains, no more pure mail trains
- Minor bugfixes

alpha4.1
- A little bugfix

alpha4
- Correcting the rail line if the AI gets interrupted while building
- Basic money handling, paying loan back
- Support for other railtypes, electrifying existing lines
- Detection of "Disable trains/roadvehicles for computer" under Advanced Settings
- Bugfixes

alpha3
- Train support (single point-to-point routes so far)
- Added settings to use trains or road vehicles only

alpha2
- Added setting to configure the chance of going for a subsidy
- Added setting to configure competition level based on the last month transported percentage
- Basic event handling
- Selling unprofitable vehicles and deleting empty routes
- Refitting road vehicles

alpha1
- Basic version, road vehicles only

6. Dependencies
---------------
SimpleAI depends on the following libraries:
- Pathfinder.Road v3
- Pathfinder.Rail v1
- Graph.Aystar v4 (a dependency of the above pathfinders)
If you downloaded this AI from the in-game content downloading system, these libraries
also got installed automatically. However if you downloaded this AI manually from the
forums or somewhere else, then you need to install these libraries as well.
The libraries can be downloaded here: http://noai.openttd.org/downloads/Libraries/
Install these libraries into the ai/library subdirectory of OpenTTD.


7. License
----------
SimpleAI is licensed under version 2 of the GNU General Public License. See license.txt
for details.
SimpleAI reuses code from NoCAB (Terraform.nut) and PAXLink (cBuilder::CostToFlattern).

8. Support
----------
Discussion about SimpleAI can be found here: http://www.tt-forums.net/viewtopic.php?f=65&t=44809
You're welcome to post bug reports and other comments :)